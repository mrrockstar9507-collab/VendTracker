# VendTracker (PWA)

This is a *hosted* installable web app version of your Vending Machine Tracker.

## What this version does
- Runs in any modern browser (iPhone/Android/Mac/Windows/Chromebook).
- Installable as an "app" (PWA) after you host it (GitHub Pages, Netlify, etc.).
- Works offline *after the first load* because it caches the app shell.

## Important: data storage
The tracker stores data in the browser on that device (LocalStorage). To move data between devices:
- Use **Export JSON** on device A
- Use **Import JSON** on device B

If you want true multi-device sync (same data everywhere automatically), you need a backend (e.g., Firebase/Firestore).

## Deploy on GitHub Pages (quick)
1. Create a new repo (public) in GitHub.
2. Upload these files to the repo root: `index.html`, `sw.js`, `app.webmanifest`, and `icons/`.
3. Go to **Settings → Pages**
4. Set **Source** = Deploy from a branch, Branch = `main` (root).
5. Wait for the Pages URL, then open it on your phone and PC.

## Install on iPhone
- Open the GitHub Pages URL in Safari
- Tap Share → **Add to Home Screen**

## Install on Android
- Open the URL in Chrome
- Menu → **Install app** (or Add to Home screen)

## Install on desktop
- Open in Chrome/Edge
- Use the install icon in the address bar (or menu → Install)

